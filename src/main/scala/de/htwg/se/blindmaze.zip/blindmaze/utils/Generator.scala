package de.htwg.se.blindmaze.utils

import de.htwg.se.blindmaze.model.grid.IGrid
import de.htwg.se.blindmaze.model.tiles.{Tile, TileContent}
import de.htwg.se.blindmaze.utils.Position
import de.htwg.se.blindmaze.model.grid.gridImp.Grid
import scala.util.Random

class Generator {
  def generateGrid(size: Int): IGrid = {
    val grid = new Grid(size)

    // Add a few random walls
    val random = new Random()
    for (_ <- 1 to (size * size / 10)) { // Place walls in ~10% of the grid
      val x = random.nextInt(size)
      val y = random.nextInt(size)
      grid.set(Position(x, y), Tile(TileContent.Wall))
    }

    // Place the VictoryTile in the center
    val center = size / 2
    grid.set(Position(center, center), Tile(TileContent.Victory))

    grid
  }
}
